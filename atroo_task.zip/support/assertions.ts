const expectChai = require('chai').expect;
const { startStep, endStep } = require('@wdio/allure-reporter').default;

class Assertions {
	async assertWindowTitle(title: string): Promise<void> {
		startStep('Check: Page title is equal to matching title.');
		await expect(browser).toHaveTitle(title);
		endStep('passed');
	}

	async assertEquals<T>(actual: T, expected: T): Promise<void> {
		startStep('Checking that Actual andExpected values are equal.');
		await expectChai(actual, `Actual value: "${actual}" is not equal to expected value: "${expected}"`)
			.be.equal(expected);
		endStep('passed');
	}

	async assertIsElementPresent(element: WebdriverIO.Element): Promise<void> {
		startStep('Check: Element is exist on the page.');
		await expectChai(element, `Element "${element}" is not exist on the page`).be.exist;
		endStep('passed');
	}

	async assertThatElementHasText(element: WebdriverIO.Element, expectedText: string): Promise<void> {
		startStep('Check: Element contains expected text content.');
		await expectChai(await element.getText(), `Actual text is ${await element.getText()}`)
			.be.equal(expectedText, `Expected text was ${expectedText}`);
		endStep('passed');
	}

	async assertIsElementClickable(element: WebdriverIO.Element): Promise<void> {
		startStep('Check: Element is clickable.');
		await expect(element).toBeClickable();
		endStep('passed');
	}

	async assertArrayLengthEqual(newsArticles: WebdriverIO.Element[], number: number): Promise<void> {
		await expectChai(newsArticles.length).be.equal(number);
	}
}

export default new Assertions();
