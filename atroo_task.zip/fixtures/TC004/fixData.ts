class FixData {
	get newsTitle(): string {
		return this.title;
	}

	set newsTitle(value: string) {
		this.title = value;
	}

	get sectionHref(): string {
		return this.href;
	}

	set sectionHref(value: string) {
		this.href = value;
	}

	private href: string;

	private title: string;
}
export default new FixData();
