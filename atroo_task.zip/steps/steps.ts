import { Given, When, Then } from '@wdio/cucumber-framework';
import AtrooPage from '../pages/atroo.page';
import Assert from '../support/assertions';
import Config from "../config/config";

const { startStep, endStep } = require('@wdio/allure-reporter').default;

Given(/^As user I open a website page$/, async () => {
	startStep('Navigate to website page');
	await AtrooPage.open(Config.portalUrl);
	endStep('passed');

	startStep('Check window title');
	await Assert.assertWindowTitle(Config.portalTitle);
	endStep('passed');
});

When(/^I click on the "Contact Us"$/, async () => {
	startStep('Navigate to page block "Contact Us".');
	const contactUsButton = await AtrooPage.contactUsButton;
	await contactUsButton.click();
	endStep('passed');
});

Then(/^I go to form "Contact Us"$/, async () => {
	startStep('Navigate to page block "Contact Us".');
	const contactUsButton = await AtrooPage.contactUsButton;
	contactUsButton.isDisplayedWithin(3000);
	await contactUsButton.click();
	endStep('passed');
});

Then(/^I submit an empty form and check that all form fields are required$/, async () => {
	startStep('I submit an empty form.');
	const submitButton = await AtrooPage.submitFormButton;
	submitButton.isDisplayedWithin(3000);
	await submitButton.click();
	endStep('passed');

	startStep('Check that "email" field is required.');
	const emailFieldError = await AtrooPage.emailFieldError;
	await Assert.assertIsElementPresent(emailFieldError);
	await Assert.assertThatElementHasText(emailFieldError, Config.fieldIsRequiredMsg);
	endStep('passed');

	startStep('Check that "textArea" field is required.');
	const textFieldError = await AtrooPage.textFieldError;
	await Assert.assertIsElementPresent(textFieldError);
	await Assert.assertThatElementHasText(textFieldError, Config.fieldIsRequiredMsg);
	endStep('passed');

	startStep('Check that "agreements checkBox" is required.');
	const agreementsError = await AtrooPage.agreementsError;
	await Assert.assertIsElementPresent(agreementsError);
	await Assert.assertThatElementHasText(agreementsError, Config.fieldIsRequiredMsg);
	endStep('passed');

	startStep('Check that "captcha" is required.');
	const capchaError = await AtrooPage.capchaError;
	await Assert.assertIsElementPresent(capchaError);
	await Assert.assertThatElementHasText(capchaError, Config.fieldIsRequiredMsg);
	endStep('passed');
})

Then('Navigate to "Latest news" section', async () => {
	startStep('Scroll page to "Latest news" section.');
	const newsSection = await AtrooPage.newsSection;
	await newsSection.scrollIntoView();
	endStep('passed');
});
