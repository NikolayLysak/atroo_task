declare namespace WebdriverIO {
	// adding command to `browser`
	interface Element {
		isDisplayedWithin: (timeout: number) => boolean
	}
}
