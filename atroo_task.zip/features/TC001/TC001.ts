import { Given, Then } from '@wdio/cucumber-framework';
import AtrooPage from '../../pages/atroo.page';
import Assert from '../../support/assertions';
import Config from "../../config/config";

Given(/^I check that page is opened$/, async () => {
	const gratingBlock = await AtrooPage.gratingBlock;
	await Assert.assertIsElementPresent(gratingBlock);
	const blockTitle = await AtrooPage.gratingBlockTitle;
	await Assert.assertThatElementHasText(blockTitle, Config.gatingBlockTitle);
});

Then(/^Button 'Contact us' should be present$/, async () => {
	const contactUsButton = await AtrooPage.contactUsButton;
	await Assert.assertIsElementPresent(contactUsButton);
	await Assert.assertIsElementClickable(contactUsButton);
});
