import { Then, When } from '@wdio/cucumber-framework';
import Assert from '../../support/assertions';
import AtrooPage from '../../pages/atroo.page';
import Config from "../../config/config";

const { startStep, endStep } = require('@wdio/allure-reporter').default;

When(/^I input (.*) into E-mail forms field$/, async (email) => {
	startStep(`Input in email field incorrect email value: "${email}".`);
	const emailField = await AtrooPage.emailField;
	await emailField.setValue(`${email}\n`);
	endStep('passed');
});

Then('Field should indicate error', async () => {
	startStep('Checking an existing error message.');
	const emailFieldError = await AtrooPage.emailFieldError;
	await Assert.assertIsElementPresent(emailFieldError);
	endStep('passed');

	startStep('Checking the correctness of the content of the error message.');
	await Assert.assertThatElementHasText(emailFieldError, Config.emailFieldErrorMsg);
	endStep('passed');
});
