import { Then, When } from '@wdio/cucumber-framework';
import Assert from '../../support/assertions';
import AtrooPage from '../../pages/atroo.page';
import FixData from '../../fixtures/TC004/fixData';
import NewBlogPage from '../../pages/new.blog.page';

const { startStep, endStep } = require('@wdio/allure-reporter').default;

Then('Check articles quantities in news block', async () => {
	startStep('Checking the number of displayed news blocks');
	const newsArticles = await AtrooPage.newsArticles;
	await Assert.assertArrayLengthEqual(newsArticles, 3);
	endStep('passed');
});

When(/^I click on article (.*) full blog is opening$/, async (artNum: number) => {
	startStep('Getting test data and opening one of the news blocks');
	const newsArticles = await AtrooPage.newsArticles;
	const newsArticleTitles = await AtrooPage.newsArticleTitles;

	FixData.sectionHref = await newsArticles[artNum - 1].getAttribute('href');
	FixData.newsTitle = await newsArticleTitles[artNum - 1].getText();

	await newsArticles[artNum - 1].click();
	endStep('passed');
});

Then('I check that the full blog was opened after clicking on the entry', async () => {
	startStep('Checking that the title of the opened page matches the title of the news block');
	const newPageTitle = await NewBlogPage.blogPageTitle;
	await Assert.assertThatElementHasText(newPageTitle, FixData.newsTitle);
	endStep('passed');

	startStep('Checking that the URL of the open page matches the link in the open news block');
	const newPageUrl = await NewBlogPage.getPageUrl();
	await Assert.assertEquals(newPageUrl, FixData.sectionHref);
	endStep('passed');
});
