import { Then } from '@wdio/cucumber-framework';
import Assert from '../../support/assertions';
import AtrooPage from '../../pages/atroo.page';

const { startStep, endStep } = require('@wdio/allure-reporter').default;

Then(/^Check that contact form in opened$/, async () => {
	startStep('Checking for the existence of the "Contact us" block');
	const contactUsSections = await AtrooPage.contactUsSection;
	await Assert.assertIsElementPresent(contactUsSections);
	endStep('passed');

	startStep('Block title check');
	const sectionTitle = await AtrooPage.sectionTitle;
	await Assert.assertIsElementPresent(sectionTitle);
	await Assert.assertThatElementHasText(sectionTitle, 'CONTACT US');
	endStep('passed');

	startStep('Checking if the email input field exists');
	const emailField = await AtrooPage.emailField;
	await Assert.assertIsElementPresent(emailField);
	endStep('passed');

	startStep('Checking if the Text area field exists');
	const textArea = await AtrooPage.textInputArea;
	await Assert.assertIsElementPresent(textArea);
	endStep('passed');
});
