import Page from './page';

class AtrooPage extends Page {
	get gratingBlock() {
		return $('div.hcl2-content');
	}

	get gratingBlockTitle() {
		return $('div.hcl2-content h1');
	}

	get contactUsButton() {
		return $('a[href="#contact"]');
	}

	get contactUsSection() {
		return $('#contact');
	}

	get newsSection() {
		return $('#news');
	}

	get sectionTitle() {
		return $('//*[@id="contact"]//h2');
	}

	get emailField() {
		return $('#wpforms-877-field_1');
	}

	get emailFieldError() {
		return $('#wpforms-877-field_1-error');
	}

	get textInputArea() {
		return $('#wpforms-877-field_2');
	}

	get newsArticles() {
		return $$('article.list-article div.list-article-thumb a');
	}

	get newsArticleTitles() {
		return $$('article.list-article .entry-title a');
	}

	get submitFormButton() {
		return $('button.wpforms-submit ');
	}

	get textFieldError() {
		return $('#wpforms-877-field_2-error');
	}

	get agreementsError() {
		return $('#wpforms-877-field_4-container label.wpforms-error');
	}

	get capchaError() {
		return $('#g-recaptcha-hidden-error');
	}
}

export default new AtrooPage();
