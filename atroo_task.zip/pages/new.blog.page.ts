import Page from './page';

class NewBlogPage extends Page {
	get blogPageTitle() {
		return $('.entry-header h1');
	}
}

export default new NewBlogPage();
