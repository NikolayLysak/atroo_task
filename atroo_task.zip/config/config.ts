class Config {
	public portalUrl: string;
	public portalTitle: string;
	public gatingBlockTitle: string;
	public emailFieldErrorMsg: string;
	public fieldIsRequiredMsg: string;

	constructor() {
		this.portalUrl = 'https://www.atroo.de/en/';
		this.portalTitle = 'atroo - Softwareentwicklung nach Maß';
		this.gatingBlockTitle = 'YOUR PARTNER FOR MODERN IT.';
		this.emailFieldErrorMsg = 'Please enter a valid email address.';
		this.fieldIsRequiredMsg = 'This field is required.'
	}
}

export default new Config()
